/* ==========================================================================
   dashboard.js — Painel operado por filtros.
   --------------------------------------------------------------------------
   O pacote de dados traz uma tabela de fatos indexada (modelo estrela). Aqui
   ela é carregada em um índice de acesso direto, e cada mudança de filtro
   apenas reconsulta esse índice e redesenha — nada é recalculado no servidor.

   Convenções de gráfico:
   - uma escala por visual, nunca dois eixos verticais;
   - legenda sempre que houver 2+ séries, mais rótulo direto quando couber,
     para que a identidade nunca dependa só da cor;
   - 2px de respiro entre barras vizinhas e segmentos empilhados;
   - grade discreta, dado em destaque.
   ========================================================================== */

(function () {
  "use strict";

  const D = window.DADOS;
  const NS = "http://www.w3.org/2000/svg";

  /* =====================================================================
     Dimensões e índice
     ===================================================================== */
  const dim = D.dimensoes;
  const ANOS = dim.anos;
  const UNIDADES = dim.unidades;
  const LOCS = dim.localizacoes;
  const DEPS = dim.dependencias;
  const ETAPAS = dim.etapas;

  const iUnidadePorNome = new Map(UNIDADES.map((u, i) => [u.nome, i]));
  const iEtapaPorChave = new Map(ETAPAS.map((e, i) => [e.chave, i]));

  /** Chave composta -> [aprovacao, reprovacao, abandono] */
  const INDICE = new Map();
  for (const f of D.fatos) {
    INDICE.set(f[0] + "|" + f[1] + "|" + f[2] + "|" + f[3] + "|" + f[4], [f[5], f[6], f[7]]);
  }

  /** Consulta pontual. Aceita nomes, devolve null quando não há medição. */
  function medir(ano, unidade, loc, dep, etapa) {
    const ia = ANOS.indexOf(ano);
    const iu = iUnidadePorNome.get(unidade);
    const il = LOCS.indexOf(loc);
    const id = DEPS.indexOf(dep);
    const ie = iEtapaPorChave.get(etapa);
    if (ia < 0 || iu === undefined || il < 0 || id < 0 || ie === undefined) return null;
    return INDICE.get(ia + "|" + iu + "|" + il + "|" + id + "|" + ie) || null;
  }

  function taxa(ano, unidade, loc, dep, etapa, indicador) {
    const v = medir(ano, unidade, loc, dep, etapa);
    if (!v) return null;
    return v[{ aprovacao: 0, reprovacao: 1, abandono: 2 }[indicador]];
  }

  const UFS = UNIDADES.filter((u) => u.tipo === "uf");

  /* PNAD indexada por ano+categoria */
  const PNAD_GEO = new Map();
  D.pnad.geografico.forEach((r) => PNAD_GEO.set(r.ano + "|" + r.categoria, r));

  /* =====================================================================
     Estado dos filtros
     ===================================================================== */
  const PADRAO = {
    ano: ANOS[ANOS.length - 1],
    unidade: D.meta.uf_foco,
    etapa: "em_total",
    dependencia: "Total",
    localizacao: "Total",
    indicador: "abandono",
  };
  const estado = { ...PADRAO };
  const ordemTabela = { coluna: "abandono", crescente: false };

  /* =====================================================================
     Utilidades
     ===================================================================== */
  const $ = (s, r) => (r || document).querySelector(s);

  function n1(v) {
    if (v === null || v === undefined || Number.isNaN(v)) return "—";
    return v.toLocaleString("pt-BR", { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  }
  const pc = (v) => (v === null || v === undefined ? "—" : n1(v) + "%");

  function cor(nome) {
    return getComputedStyle(document.documentElement).getPropertyValue(nome).trim();
  }

  const CORES = {
    aprovacao: () => cor("--s-aprovacao"),
    reprovacao: () => cor("--s-reprovacao"),
    abandono: () => cor("--s-abandono"),
  };
  const ROTULO_IND = {
    aprovacao: "Aprovação",
    reprovacao: "Reprovação",
    abandono: "Abandono",
  };

  function el(tag, attrs, filhos) {
    const node = document.createElementNS(NS, tag);
    for (const k in attrs || {}) {
      if (attrs[k] !== null && attrs[k] !== undefined) node.setAttribute(k, attrs[k]);
    }
    (filhos || []).forEach((f) => node.appendChild(f));
    return node;
  }

  function txt(conteudo, attrs) {
    const t = el("text", attrs);
    t.textContent = conteudo;
    return t;
  }

  /** Barra vertical: topo arredondado, base reta (está ancorada no zero). */
  function barraV(x, y, w, h, r) {
    const rr = Math.max(0, Math.min(r, w / 2, h));
    return `M${x} ${y + h}L${x} ${y + rr}Q${x} ${y} ${x + rr} ${y}L${x + w - rr} ${y}Q${x + w} ${y} ${x + w} ${y + rr}L${x + w} ${y + h}Z`;
  }

  /** Barra horizontal: ponta direita arredondada. */
  function barraH(x, y, w, h, r) {
    const rr = Math.max(0, Math.min(r, h / 2, w));
    return `M${x} ${y}L${x + w - rr} ${y}Q${x + w} ${y} ${x + w} ${y + rr}L${x + w} ${y + h - rr}Q${x + w} ${y + h} ${x + w - rr} ${y + h}L${x} ${y + h}Z`;
  }

  function escala(maximo, passos) {
    if (!(maximo > 0)) return { topo: 1, ticks: [0, 0.5, 1] };
    const bruto = maximo / (passos || 4);
    const mag = Math.pow(10, Math.floor(Math.log10(bruto)));
    const norm = bruto / mag;
    const passo = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 5 ? 5 : 10) * mag;
    const topo = Math.ceil(maximo / passo) * passo;
    const ticks = [];
    for (let v = 0; v <= topo + 1e-9; v += passo) ticks.push(Number(v.toFixed(6)));
    return { topo, ticks };
  }

  function novoSvg(container, altura) {
    container.innerHTML = "";
    const largura = Math.max(300, container.clientWidth || 560);
    const svg = el("svg", {
      width: largura, height: altura,
      viewBox: `0 0 ${largura} ${altura}`, role: "img",
    });
    container.appendChild(svg);
    return { svg, largura, altura };
  }

  function eixoY(g, ticks, topo, a, sufixo) {
    ticks.forEach((t) => {
      const y = a.y + a.h - (t / topo) * a.h;
      g.appendChild(el("line", {
        x1: a.x, x2: a.x + a.w, y1: y, y2: y,
        class: "grade-linha", "stroke-width": 1,
      }));
      g.appendChild(txt(n1(t).replace(",0", "") + (sufixo || ""), {
        x: a.x - 6, y: y + 3.5, "text-anchor": "end", class: "eixo-texto",
      }));
    });
  }

  function legenda(container, itens) {
    const div = document.createElement("div");
    div.className = "legenda";
    itens.forEach((i) => {
      const s = document.createElement("span");
      s.className = "legenda__item";
      s.innerHTML = `<span class="legenda__marca" style="background:${i.cor}"></span>`;
      s.appendChild(document.createTextNode(i.rotulo));
      div.appendChild(s);
    });
    container.appendChild(div);
  }

  /* =====================================================================
     Dica flutuante
     ===================================================================== */
  const dica = document.createElement("div");
  dica.className = "dica";
  dica.hidden = true;
  dica.setAttribute("role", "status");
  document.body.appendChild(dica);

  function mostrar(ev, titulo, linhas) {
    dica.innerHTML = "";
    const h = document.createElement("div");
    h.className = "dica__titulo";
    h.textContent = titulo;
    dica.appendChild(h);
    linhas.forEach((l) => {
      const d = document.createElement("div");
      d.className = "dica__linha";
      if (l.cor) {
        const m = document.createElement("span");
        m.className = "legenda__marca";
        m.style.background = l.cor;
        d.appendChild(m);
      }
      d.appendChild(document.createTextNode(l.rotulo));
      const b = document.createElement("b");
      b.textContent = l.valor;
      d.appendChild(b);
      dica.appendChild(d);
    });
    dica.hidden = false;
    posicionar(ev);
  }

  function posicionar(ev) {
    const m = 14;
    const c = dica.getBoundingClientRect();
    let x = ev.clientX + m;
    let y = ev.clientY + m;
    if (x + c.width > window.innerWidth - 8) x = ev.clientX - c.width - m;
    if (y + c.height > window.innerHeight - 8) y = ev.clientY - c.height - m;
    dica.style.left = Math.max(8, x) + "px";
    dica.style.top = Math.max(8, y) + "px";
  }

  const esconder = () => { dica.hidden = true; };

  function comDica(node, titulo, linhas, aoClicar) {
    node.addEventListener("mouseenter", (e) => mostrar(e, titulo, linhas));
    node.addEventListener("mousemove", posicionar);
    node.addEventListener("mouseleave", esconder);
    if (aoClicar) {
      node.classList.add("marca-clicavel");
      node.addEventListener("click", () => { esconder(); aoClicar(); });
    }
    return node;
  }

  /* =====================================================================
     VISUAL 1 — Trajetória escolar, série a série
     O gráfico central do painel: mostra em que ponto da vida escolar o
     indicador salta.
     ===================================================================== */
  function desenharTrajetoria() {
    const c = $("#v-trajetoria");
    const chaves = dim.trajetoria;
    const dados = chaves.map((k) => ({
      chave: k,
      rotulo: (ETAPAS[iEtapaPorChave.get(k)] || {}).rotulo || k,
      valor: taxa(estado.ano, estado.unidade, estado.localizacao,
                  estado.dependencia, k, estado.indicador),
    }));

    const alt = 260;
    const { svg, largura } = novoSvg(c, alt);
    const a = { x: 34, y: 14, w: largura - 44, h: alt - 14 - 42 };

    const maxv = Math.max(...dados.map((d) => d.valor || 0), 0.5);
    const { topo, ticks } = escala(maxv * 1.18, 4);

    const g = el("g");
    svg.appendChild(g);
    eixoY(g, ticks, topo, a, "%");

    const passo = a.w / dados.length;
    const wBarra = Math.min(38, passo - 5);
    const corBase = CORES[estado.indicador]();

    // A fronteira entre Fundamental e Médio é informação, não enfeite:
    // é onde o aluno troca de rede e de escola.
    const iFronteira = chaves.findIndex((k) => k.startsWith("em_"));
    if (iFronteira > 0) {
      const xf = a.x + iFronteira * passo;
      g.appendChild(el("line", {
        x1: xf, x2: xf, y1: a.y, y2: a.y + a.h,
        stroke: cor("--borda-forte"), "stroke-width": 1, "stroke-dasharray": "3 3",
      }));
      g.appendChild(txt("Ensino Médio →", {
        x: xf + 5, y: a.y + 9, class: "eixo-texto", fill: cor("--texto-3"),
      }));
    }

    dados.forEach((d, i) => {
      const x = a.x + i * passo + (passo - wBarra) / 2;
      if (d.valor !== null) {
        const h = (d.valor / topo) * a.h;
        const marca = el("path", {
          d: barraV(x, a.y + a.h - h, wBarra, Math.max(h, 1), 3),
          fill: corBase,
        });
        comDica(marca, d.rotulo, [
          { cor: corBase, rotulo: ROTULO_IND[estado.indicador], valor: pc(d.valor) },
          { rotulo: "Ano", valor: String(estado.ano) },
        ]);
        g.appendChild(marca);
        g.appendChild(txt(n1(d.valor), {
          x: x + wBarra / 2, y: a.y + a.h - h - 4,
          "text-anchor": "middle", class: "rotulo-valor",
        }));
      }
      g.appendChild(txt(d.rotulo.replace(" ano", "º").replace(" série", "ª"), {
        x: x + wBarra / 2, y: a.y + a.h + 14,
        "text-anchor": "middle", class: "eixo-texto",
      }));
    });

    g.appendChild(txt("Ensino Fundamental", {
      x: a.x, y: alt - 6, class: "eixo-texto", fill: cor("--texto-3"),
    }));
    g.appendChild(txt("Ensino Médio", {
      x: a.x + a.w, y: alt - 6, "text-anchor": "end",
      class: "eixo-texto", fill: cor("--texto-3"),
    }));
  }

  /* =====================================================================
     VISUAL 2 — Evolução das três taxas
     ===================================================================== */
  function desenharEvolucao() {
    const c = $("#v-evolucao");
    const series = ["aprovacao", "reprovacao", "abandono"].map((k) => ({
      chave: k,
      rotulo: ROTULO_IND[k],
      cor: CORES[k](),
      pontos: ANOS.map((ano) => ({
        ano,
        v: taxa(ano, estado.unidade, estado.localizacao, estado.dependencia, estado.etapa, k),
      })),
    }));

    // Aprovação fica perto de 95% e as outras perto de 3%: numa escala só,
    // as duas de baixo viram uma linha reta colada no eixo. Por isso este
    // visual mostra reprovação e abandono, que é onde a variação está.
    const visiveis = series.filter((s) => s.chave !== "aprovacao");

    const alt = 210;
    const { svg, largura } = novoSvg(c, alt);
    // A margem direita guarda o rótulo direto de cada série; sem ela o
    // texto sai cortado na borda do cartão.
    const a = { x: 32, y: 12, w: largura - 32 - 82, h: alt - 12 - 26 };

    const maxv = Math.max(...visiveis.flatMap((s) => s.pontos.map((p) => p.v || 0)), 0.5);
    const { topo, ticks } = escala(maxv * 1.2, 4);

    const g = el("g");
    svg.appendChild(g);
    eixoY(g, ticks, topo, a, "%");

    const px = (i) => a.x + (ANOS.length === 1 ? 0 : (i / (ANOS.length - 1)) * a.w);
    const py = (v) => a.y + a.h - (v / topo) * a.h;

    ANOS.forEach((ano, i) => {
      g.appendChild(txt(ano, {
        x: px(i), y: a.y + a.h + 15, "text-anchor": "middle", class: "eixo-texto",
      }));
      if (ano === estado.ano) {
        g.appendChild(el("line", {
          x1: px(i), x2: px(i), y1: a.y, y2: a.y + a.h,
          stroke: cor("--verde-200"), "stroke-width": 2,
        }));
      }
    });

    visiveis.forEach((s) => {
      const ok = s.pontos.map((p, i) => ({ ...p, i })).filter((p) => p.v !== null);
      if (!ok.length) return;
      g.appendChild(el("path", {
        d: ok.map((p, k) => (k ? "L" : "M") + px(p.i) + " " + py(p.v)).join(" "),
        fill: "none", stroke: s.cor, "stroke-width": 2,
        "stroke-linejoin": "round", "stroke-linecap": "round",
      }));
      ok.forEach((p) => {
        g.appendChild(el("circle", {
          cx: px(p.i), cy: py(p.v), r: 3.5, fill: s.cor,
          stroke: cor("--cartao"), "stroke-width": 1.5,
        }));
        const alvo = el("circle", { cx: px(p.i), cy: py(p.v), r: 11, fill: "transparent" });
        comDica(alvo, s.rotulo + " · " + p.ano, [
          { cor: s.cor, rotulo: s.rotulo, valor: pc(p.v) },
          {
            rotulo: "Aprovação",
            valor: pc(taxa(p.ano, estado.unidade, estado.localizacao,
                           estado.dependencia, estado.etapa, "aprovacao")),
          },
        ], () => { estado.ano = p.ano; sincronizarControles(); redesenhar(); });
        g.appendChild(alvo);
      });
      const u = ok[ok.length - 1];
      g.appendChild(txt(s.rotulo, {
        x: px(u.i) + 8, y: py(u.v) + 3, class: "rotulo-serie", fill: s.cor,
      }));
    });

    legenda(c, visiveis.map((s) => ({ cor: s.cor, rotulo: s.rotulo })));
  }

  /* =====================================================================
     VISUAL 3 — Rede de ensino
     ===================================================================== */
  function desenharRedes() {
    const c = $("#v-redes");
    const redes = DEPS.filter((d) => d !== "Total");
    const dados = redes.map((d) => ({
      rede: d,
      cor: cor("--rede-" + d.toLowerCase()),
      v: taxa(estado.ano, estado.unidade, estado.localizacao, d, estado.etapa, estado.indicador),
    })).filter((d) => d.v !== null);

    const alt = 210;
    const { svg, largura } = novoSvg(c, alt);
    const a = { x: 32, y: 12, w: largura - 42, h: alt - 12 - 26 };

    if (!dados.length) {
      c.innerHTML = '<p style="font-size:11.5px;color:var(--texto-3);padding:20px 0">' +
        "Nenhuma rede oferta esta etapa neste recorte.</p>";
      return;
    }

    const { topo, ticks } = escala(Math.max(...dados.map((d) => d.v), 0.5) * 1.2, 4);
    const g = el("g");
    svg.appendChild(g);
    eixoY(g, ticks, topo, a, "%");

    const passo = a.w / dados.length;
    const w = Math.min(56, passo - 12);

    dados.forEach((d, i) => {
      const x = a.x + i * passo + (passo - w) / 2;
      const h = (d.v / topo) * a.h;
      const marca = el("path", {
        d: barraV(x, a.y + a.h - h, w, Math.max(h, 1), 3), fill: d.cor,
      });
      comDica(marca, "Rede " + d.rede, [
        { cor: d.cor, rotulo: ROTULO_IND[estado.indicador], valor: pc(d.v) },
      ], () => { estado.dependencia = d.rede; sincronizarControles(); redesenhar(); });
      g.appendChild(marca);
      g.appendChild(txt(n1(d.v), {
        x: x + w / 2, y: a.y + a.h - h - 4, "text-anchor": "middle", class: "rotulo-valor",
      }));
      g.appendChild(txt(d.rede, {
        x: x + w / 2, y: a.y + a.h + 15, "text-anchor": "middle", class: "eixo-texto",
      }));
    });
  }

  /* =====================================================================
     VISUAL 4 — Urbana × Rural
     ===================================================================== */
  function desenharLocalizacao() {
    const c = $("#v-localizacao");
    const dados = ["Urbana", "Rural"].map((l) => ({
      loc: l,
      v: taxa(estado.ano, estado.unidade, l, estado.dependencia, estado.etapa, estado.indicador),
    })).filter((d) => d.v !== null);

    const alt = 210;
    const { svg, largura } = novoSvg(c, alt);
    const a = { x: 32, y: 12, w: largura - 42, h: alt - 12 - 26 };

    if (!dados.length) {
      c.innerHTML = '<p style="font-size:11.5px;color:var(--texto-3);padding:20px 0">Sem dado neste recorte.</p>';
      return;
    }

    const { topo, ticks } = escala(Math.max(...dados.map((d) => d.v), 0.5) * 1.25, 4);
    const g = el("g");
    svg.appendChild(g);
    eixoY(g, ticks, topo, a, "%");

    const corBase = CORES[estado.indicador]();
    const passo = a.w / dados.length;
    const w = Math.min(72, passo - 24);

    dados.forEach((d, i) => {
      const x = a.x + i * passo + (passo - w) / 2;
      const h = (d.v / topo) * a.h;
      const marca = el("path", {
        d: barraV(x, a.y + a.h - h, w, Math.max(h, 1), 3), fill: corBase,
      });
      comDica(marca, "Zona " + d.loc, [
        { cor: corBase, rotulo: ROTULO_IND[estado.indicador], valor: pc(d.v) },
      ], () => { estado.localizacao = d.loc; sincronizarControles(); redesenhar(); });
      g.appendChild(marca);
      g.appendChild(txt(n1(d.v), {
        x: x + w / 2, y: a.y + a.h - h - 4, "text-anchor": "middle", class: "rotulo-valor",
      }));
      g.appendChild(txt(d.loc, {
        x: x + w / 2, y: a.y + a.h + 15, "text-anchor": "middle", class: "eixo-texto",
      }));
    });
  }

  /* =====================================================================
     VISUAL 5 — Ranking das UFs (clicar troca a unidade em foco)
     ===================================================================== */
  function desenharRanking() {
    const c = $("#v-ranking");
    const lista = UFS.map((u) => ({
      nome: u.nome,
      sigla: u.uf,
      v: taxa(estado.ano, u.nome, estado.localizacao, estado.dependencia, estado.etapa, estado.indicador),
    })).filter((d) => d.v !== null)
      .sort((x, y) => (estado.indicador === "aprovacao" ? x.v - y.v : y.v - x.v));

    const linhaAlt = 15;
    const alt = lista.length * linhaAlt + 10;
    const { svg, largura } = novoSvg(c, alt);
    const a = { x: 30, y: 4, w: largura - 30 - 40, h: lista.length * linhaAlt };

    const { topo } = escala(Math.max(...lista.map((d) => d.v), 0.5) * 1.08, 4);
    const g = el("g");
    svg.appendChild(g);
    const corBase = CORES[estado.indicador]();
    const corContexto = cor("--verde-300");

    lista.forEach((d, i) => {
      const y = a.y + i * linhaAlt;
      const foco = d.nome === estado.unidade;
      const w = Math.max(2, (d.v / topo) * a.w);

      g.appendChild(txt(d.sigla, {
        x: a.x - 6, y: y + linhaAlt / 2 + 3, "text-anchor": "end",
        class: "eixo-texto",
        fill: foco ? cor("--verde-900") : cor("--texto-3"),
        "font-weight": foco ? 700 : 400,
      }));

      const marca = el("path", {
        d: barraH(a.x, y + 2.5, w, linhaAlt - 5, 2),
        fill: foco ? corBase : corContexto,
      });
      comDica(marca, d.nome, [
        { cor: foco ? corBase : corContexto, rotulo: ROTULO_IND[estado.indicador], valor: pc(d.v) },
        { rotulo: "Clique", valor: "ver esta UF" },
      ], () => { estado.unidade = d.nome; sincronizarControles(); redesenhar(); });
      g.appendChild(marca);

      g.appendChild(txt(n1(d.v), {
        x: a.x + w + 5, y: y + linhaAlt / 2 + 3, class: "rotulo-valor",
        "font-weight": foco ? 700 : 400,
      }));
    });
  }

  /* =====================================================================
     VISUAL 6 — Dispersão: desocupação (IBGE) × indicador escolar (INEP)
     É o cruzamento das duas bases. Todos os pares possíveis podem ficar
     lado a lado, então a paleta se limita a duas cores: a UF em foco e o
     resto.
     ===================================================================== */
  function desenharDispersao() {
    const c = $("#v-dispersao");
    const pontos = UFS.map((u) => {
      const p = PNAD_GEO.get(estado.ano + "|" + u.nome);
      const e = taxa(estado.ano, u.nome, estado.localizacao, estado.dependencia,
                     estado.etapa, estado.indicador);
      return p && e !== null && p.taxa_desocupacao !== null
        ? { nome: u.nome, sigla: u.uf, x: p.taxa_desocupacao, y: e }
        : null;
    }).filter(Boolean);

    const alt = 260;
    const { svg, largura } = novoSvg(c, alt);
    const a = { x: 34, y: 12, w: largura - 44, h: alt - 12 - 34 };

    if (pontos.length < 3) {
      c.innerHTML = '<p style="font-size:11.5px;color:var(--texto-3);padding:20px 0">Sem dado suficiente neste recorte.</p>';
      return;
    }

    const ex = escala(Math.max(...pontos.map((p) => p.x)) * 1.1, 4);
    const ey = escala(Math.max(...pontos.map((p) => p.y)) * 1.15, 4);
    const g = el("g");
    svg.appendChild(g);
    eixoY(g, ey.ticks, ey.topo, a, "%");

    ex.ticks.forEach((t) => {
      const x = a.x + (t / ex.topo) * a.w;
      g.appendChild(el("line", {
        x1: x, x2: x, y1: a.y, y2: a.y + a.h, class: "grade-linha", "stroke-width": 1,
      }));
      g.appendChild(txt(n1(t).replace(",0", "") + "%", {
        x, y: a.y + a.h + 14, "text-anchor": "middle", class: "eixo-texto",
      }));
    });

    const corBase = CORES[estado.indicador]();
    const corOutros = cor("--verde-300");

    pontos.forEach((p) => {
      const cx = a.x + (p.x / ex.topo) * a.w;
      const cy = a.y + a.h - (p.y / ey.topo) * a.h;
      const foco = p.nome === estado.unidade;
      const marca = el("circle", {
        cx, cy, r: foco ? 7 : 5,
        fill: foco ? corBase : corOutros,
        stroke: cor("--cartao"), "stroke-width": 1.5,
      });
      comDica(marca, p.nome, [
        { rotulo: "Desocupação", valor: pc(p.x) },
        { cor: foco ? corBase : corOutros, rotulo: ROTULO_IND[estado.indicador], valor: pc(p.y) },
      ], () => { estado.unidade = p.nome; sincronizarControles(); redesenhar(); });
      g.appendChild(marca);
      if (foco) {
        g.appendChild(txt(p.sigla, {
          x: cx, y: cy - 11, "text-anchor": "middle",
          class: "rotulo-serie", fill: cor("--verde-900"),
        }));
      }
    });

    g.appendChild(txt("Taxa de desocupação da UF (PNAD Contínua) →", {
      x: a.x, y: alt - 4, class: "eixo-texto",
    }));
  }

  /* =====================================================================
     VISUAL 7 — Desocupação por nível de instrução (PNAD, Brasil)
     ===================================================================== */
  function desenharInstrucao() {
    const c = $("#v-instrucao");
    const anos = D.pnad.anos_perfil;
    // O perfil nacional não cobre todos os anos da série escolar; usamos o
    // ano disponível mais próximo do selecionado.
    const ano = anos.reduce((a, b) =>
      Math.abs(b - estado.ano) < Math.abs(a - estado.ano) ? b : a, anos[0]);

    // Instrução é uma sequência, não um conjunto de rótulos: ordenar por
    // valor destruiria a leitura. Seguimos a ordem escolar declarada pelo
    // pipeline e damos à barra uma rampa de um só tom, do claro ao escuro,
    // para que a própria cor mostre o avanço.
    const ordem = D.pnad.ordem_instrucao || [];
    const rampa = ["#86b6ef", "#3987e5", "#1c5cab", "#0d366b"];
    const dados = ordem
      .map((nivel) => D.pnad.nivel_instrucao.find(
        (r) => r.ano === ano && r.categoria === nivel && r.taxa_desocupacao !== null))
      .filter(Boolean)
      .map((r, i) => ({ rotulo: r.categoria, v: r.taxa_desocupacao, cor: rampa[i] || rampa[rampa.length - 1] }));

    $("#v-instrucao-ano").textContent = "PNAD " + ano;

    const linhaAlt = 30;
    const alt = dados.length * linhaAlt + 8;
    const { svg, largura } = novoSvg(c, alt);
    const rot = Math.min(240, Math.max(120, largura * 0.42));
    const a = { x: rot, y: 4, w: largura - rot - 40, h: dados.length * linhaAlt };

    const { topo } = escala(Math.max(...dados.map((d) => d.v), 1) * 1.1, 4);
    const g = el("g");
    svg.appendChild(g);

    dados.forEach((d, i) => {
      const y = a.y + i * linhaAlt;
      const w = Math.max(2, (d.v / topo) * a.w);

      // Rótulo longo quebrado em duas linhas, para não estourar a coluna.
      const palavras = d.rotulo.split(" ");
      const meio = Math.ceil(palavras.length / 2);
      const l1 = palavras.slice(0, meio).join(" ");
      const l2 = palavras.slice(meio).join(" ");
      g.appendChild(txt(l1, {
        x: a.x - 8, y: y + linhaAlt / 2 - 1, "text-anchor": "end", class: "eixo-texto",
      }));
      if (l2) {
        g.appendChild(txt(l2, {
          x: a.x - 8, y: y + linhaAlt / 2 + 9, "text-anchor": "end", class: "eixo-texto",
        }));
      }

      const marca = el("path", { d: barraH(a.x, y + 6, w, linhaAlt - 14, 3), fill: d.cor });
      comDica(marca, d.rotulo, [
        { cor: d.cor, rotulo: "Desocupação", valor: pc(d.v) },
        { rotulo: "Ano", valor: String(ano) },
      ]);
      g.appendChild(marca);
      g.appendChild(txt(n1(d.v) + "%", {
        x: a.x + w + 5, y: y + linhaAlt / 2 + 3, class: "rotulo-valor",
      }));
    });
  }

  /* =====================================================================
     KPIs
     ===================================================================== */
  function faisca(valores, corLinha) {
    const w = 84, h = 22;
    const svg = el("svg", { width: w, height: h, viewBox: `0 0 ${w} ${h}`, class: "faisca" });
    const ok = valores.map((v, i) => ({ v, i })).filter((p) => p.v !== null);
    if (ok.length < 2) return svg;
    const min = Math.min(...ok.map((p) => p.v));
    const max = Math.max(...ok.map((p) => p.v));
    const amp = max - min || 1;
    const px = (i) => (i / (valores.length - 1)) * (w - 4) + 2;
    const py = (v) => h - 3 - ((v - min) / amp) * (h - 8);
    svg.appendChild(el("path", {
      d: ok.map((p, k) => (k ? "L" : "M") + px(p.i) + " " + py(p.v)).join(" "),
      fill: "none", stroke: corLinha, "stroke-width": 1.5,
      "stroke-linejoin": "round", "stroke-linecap": "round",
    }));
    const u = ok[ok.length - 1];
    svg.appendChild(el("circle", { cx: px(u.i), cy: py(u.v), r: 2.5, fill: corLinha }));
    return svg;
  }

  function montarKpis() {
    const alvo = $("#kpis");
    alvo.innerHTML = "";

    const anoAnterior = ANOS[ANOS.indexOf(estado.ano) - 1];

    const cartoes = ["aprovacao", "reprovacao", "abandono"].map((k) => {
      const atual = taxa(estado.ano, estado.unidade, estado.localizacao,
                         estado.dependencia, estado.etapa, k);
      const antes = anoAnterior === undefined ? null
        : taxa(anoAnterior, estado.unidade, estado.localizacao,
               estado.dependencia, estado.etapa, k);
      return {
        rotulo: ROTULO_IND[k],
        cor: CORES[k](),
        valor: atual,
        // Subir é bom para aprovação e ruim para as outras duas. Pintar
        // toda alta de vermelho diria que mais aprovação é má notícia.
        subirEBom: k === "aprovacao",
        delta: atual !== null && antes !== null ? Math.round((atual - antes) * 10) / 10 : null,
        serie: ANOS.map((ano) => taxa(ano, estado.unidade, estado.localizacao,
                                      estado.dependencia, estado.etapa, k)),
        base: anoAnterior === undefined ? "sem ano anterior" : "vs. " + anoAnterior,
      };
    });

    const pnad = PNAD_GEO.get(estado.ano + "|" + estado.unidade);
    cartoes.push({
      rotulo: "Desocupação",
      cor: cor("--rede-estadual"),
      subirEBom: false,
      valor: pnad ? pnad.taxa_desocupacao : null,
      delta: (() => {
        const a = PNAD_GEO.get(anoAnterior + "|" + estado.unidade);
        return pnad && a && a.taxa_desocupacao !== null && pnad.taxa_desocupacao !== null
          ? Math.round((pnad.taxa_desocupacao - a.taxa_desocupacao) * 10) / 10 : null;
      })(),
      serie: ANOS.map((ano) => {
        const r = PNAD_GEO.get(ano + "|" + estado.unidade);
        return r ? r.taxa_desocupacao : null;
      }),
      base: "PNAD Contínua · " + (anoAnterior === undefined ? "—" : "vs. " + anoAnterior),
    });

    cartoes.forEach((k) => {
      const art = document.createElement("article");
      art.className = "kpi";
      art.style.setProperty("--kpi-cor", k.cor);

      const rot = document.createElement("span");
      rot.className = "kpi__rotulo";
      rot.innerHTML = `<span class="legenda__marca" style="background:${k.cor}"></span>`;
      rot.appendChild(document.createTextNode(k.rotulo));
      art.appendChild(rot);

      const val = document.createElement("span");
      val.className = "kpi__valor";
      val.textContent = n1(k.valor);
      const un = document.createElement("small");
      un.textContent = "%";
      val.appendChild(un);
      art.appendChild(val);

      const rodape = document.createElement("span");
      rodape.className = "kpi__rodape";
      const d = k.delta;
      let classe = "delta--igual", seta = "→";
      if (d !== null && d !== 0) {
        const subiu = d > 0;
        seta = subiu ? "▲" : "▼";
        classe = subiu === k.subirEBom ? "delta--bom" : "delta--ruim";
      }
      const pil = document.createElement("span");
      pil.className = "delta " + classe;
      pil.textContent = d === null ? "— p.p."
        : seta + " " + (d > 0 ? "+" : d < 0 ? "−" : "") + n1(Math.abs(d)) + " p.p.";
      rodape.appendChild(pil);
      rodape.appendChild(document.createTextNode(k.base));
      art.appendChild(rodape);

      art.appendChild(faisca(k.serie, k.cor));
      alvo.appendChild(art);
    });
  }

  /* =====================================================================
     Tabela
     ===================================================================== */
  function montarTabela() {
    const linhas = UFS.map((u) => {
      const v = medir(estado.ano, u.nome, estado.localizacao, estado.dependencia, estado.etapa);
      const p = PNAD_GEO.get(estado.ano + "|" + u.nome);
      return {
        nome: u.nome, sigla: u.uf, regiao: u.regiao,
        aprovacao: v ? v[0] : null,
        reprovacao: v ? v[1] : null,
        abandono: v ? v[2] : null,
        desocupacao: p ? p.taxa_desocupacao : null,
      };
    });

    const { coluna, crescente } = ordemTabela;
    linhas.sort((a, b) => {
      const va = a[coluna], vb = b[coluna];
      if (typeof va === "string") {
        return crescente ? va.localeCompare(vb, "pt-BR") : vb.localeCompare(va, "pt-BR");
      }
      const na = va === null ? -Infinity : va;
      const nb = vb === null ? -Infinity : vb;
      return crescente ? na - nb : nb - na;
    });

    const corpo = $("#tabela-corpo");
    corpo.innerHTML = "";
    linhas.forEach((l) => {
      const tr = document.createElement("tr");
      if (l.nome === estado.unidade) tr.className = "destaque";
      tr.tabIndex = 0;
      tr.addEventListener("click", () => {
        estado.unidade = l.nome; sincronizarControles(); redesenhar();
      });
      tr.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          estado.unidade = l.nome; sincronizarControles(); redesenhar();
        }
      });

      const td0 = document.createElement("td");
      td0.textContent = l.nome;
      tr.appendChild(td0);
      const td1 = document.createElement("td");
      td1.textContent = l.regiao || "—";
      tr.appendChild(td1);
      ["aprovacao", "reprovacao", "abandono", "desocupacao"].forEach((k) => {
        const td = document.createElement("td");
        td.className = "num";
        td.textContent = pc(l[k]);
        tr.appendChild(td);
      });
      corpo.appendChild(tr);
    });

    document.querySelectorAll("#tabela thead th").forEach((th) => {
      const ativa = th.dataset.coluna === ordemTabela.coluna;
      th.setAttribute("aria-sort", ativa ? (ordemTabela.crescente ? "ascending" : "descending") : "none");
      th.textContent = th.dataset.rotulo + (ativa ? (ordemTabela.crescente ? " ▲" : " ▼") : "");
    });
  }

  /* =====================================================================
     Controles
     ===================================================================== */
  function fatia(grupo, nome, valor, rotulo, marcado, corMarca) {
    const label = document.createElement("label");
    label.className = "fatia";
    const input = document.createElement("input");
    input.type = "radio";
    input.name = nome;
    input.value = valor;
    input.id = nome + "-" + String(valor).replace(/\W+/g, "");
    input.checked = marcado;
    label.appendChild(input);
    if (corMarca) {
      const m = document.createElement("span");
      m.className = "marca-cor";
      m.style.background = corMarca;
      label.appendChild(m);
    }
    label.appendChild(document.createTextNode(rotulo));
    grupo.appendChild(label);
    return input;
  }

  function montarControles() {
    // Ano
    const gAno = $("#f-ano");
    ANOS.forEach((ano) => {
      const i = fatia(gAno, "ano", ano, String(ano), ano === estado.ano);
      i.addEventListener("change", () => { estado.ano = ano; redesenhar(); });
    });

    // Indicador
    const gInd = $("#f-indicador");
    ["abandono", "reprovacao", "aprovacao"].forEach((k) => {
      const i = fatia(gInd, "indicador", k, ROTULO_IND[k], k === estado.indicador, CORES[k]());
      i.addEventListener("change", () => { estado.indicador = k; redesenhar(); });
    });

    // Etapa
    const gEtapa = $("#f-etapa");
    Object.keys(dim.etapas_filtro).forEach((k) => {
      const i = fatia(gEtapa, "etapa", k, dim.etapas_filtro[k], k === estado.etapa);
      i.addEventListener("change", () => { estado.etapa = k; redesenhar(); });
    });

    // Rede
    const gRede = $("#f-rede");
    DEPS.forEach((d) => {
      const i = fatia(gRede, "rede", d, d, d === estado.dependencia,
                      d === "Total" ? null : cor("--rede-" + d.toLowerCase()));
      i.addEventListener("change", () => { estado.dependencia = d; redesenhar(); });
    });

    // Localização
    const gLoc = $("#f-local");
    LOCS.forEach((l) => {
      const i = fatia(gLoc, "local", l, l, l === estado.localizacao);
      i.addEventListener("change", () => { estado.localizacao = l; redesenhar(); });
    });

    // Unidade geográfica
    const sel = $("#f-unidade");
    const grupos = { pais: "País", regiao: "Grandes Regiões", uf: "Unidades da Federação" };
    Object.keys(grupos).forEach((tipo) => {
      const og = document.createElement("optgroup");
      og.label = grupos[tipo];
      UNIDADES.filter((u) => u.tipo === tipo).forEach((u) => {
        const o = document.createElement("option");
        o.value = u.nome;
        o.textContent = u.nome;
        og.appendChild(o);
      });
      sel.appendChild(og);
    });
    sel.value = estado.unidade;
    sel.addEventListener("change", () => { estado.unidade = sel.value; redesenhar(); });

    // Limpar
    $("#limpar").addEventListener("click", () => {
      Object.assign(estado, PADRAO);
      sincronizarControles();
      redesenhar();
    });

    // Ordenação da tabela
    document.querySelectorAll("#tabela thead th").forEach((th) => {
      th.addEventListener("click", () => {
        const c = th.dataset.coluna;
        if (ordemTabela.coluna === c) ordemTabela.crescente = !ordemTabela.crescente;
        else { ordemTabela.coluna = c; ordemTabela.crescente = c === "nome"; }
        montarTabela();
      });
    });
  }

  /** Reflete o estado nos controles — usado quando um clique num visual
      muda o filtro (o "cross-filter" de um relatório de BI). */
  function sincronizarControles() {
    const set = (nome, valor) => {
      const i = document.querySelector(`input[name="${nome}"][value="${CSS.escape(String(valor))}"]`);
      if (i) i.checked = true;
    };
    set("ano", estado.ano);
    set("indicador", estado.indicador);
    set("etapa", estado.etapa);
    set("rede", estado.dependencia);
    set("local", estado.localizacao);
    $("#f-unidade").value = estado.unidade;
  }

  /* =====================================================================
     Contexto textual
     ===================================================================== */
  function atualizarContexto() {
    const etapa = dim.etapas_filtro[estado.etapa] || estado.etapa;
    const partes = [estado.unidade, etapa, String(estado.ano)];
    if (estado.dependencia !== "Total") partes.push("rede " + estado.dependencia);
    if (estado.localizacao !== "Total") partes.push("zona " + estado.localizacao);

    document.querySelectorAll("[data-contexto]").forEach((n) => {
      n.textContent = partes.join(" · ");
    });
    document.querySelectorAll("[data-unidade]").forEach((n) => { n.textContent = estado.unidade; });
    document.querySelectorAll("[data-ano]").forEach((n) => { n.textContent = estado.ano; });
    document.querySelectorAll("[data-indicador]").forEach((n) => {
      n.textContent = ROTULO_IND[estado.indicador].toLowerCase();
    });
    document.querySelectorAll("[data-etapa]").forEach((n) => {
      n.textContent = dim.etapas_filtro[estado.etapa] || estado.etapa;
    });
  }

  /* =====================================================================
     Redesenho
     ===================================================================== */
  function redesenhar() {
    atualizarContexto();
    montarKpis();
    desenharTrajetoria();
    desenharEvolucao();
    desenharRedes();
    desenharLocalizacao();
    desenharRanking();
    desenharDispersao();
    desenharInstrucao();
    montarTabela();
  }

  function iniciar() {
    if (!D) return;
    $("#meta-periodo").textContent = D.meta.periodo;
    $("#meta-gerado").textContent = new Date(D.meta.gerado_em)
      .toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });

    montarControles();
    redesenhar();

    let t;
    window.addEventListener("resize", () => {
      clearTimeout(t);
      t = setTimeout(redesenhar, 160);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", iniciar);
  } else {
    iniciar();
  }
})();
